/**
 *   \file solver.h
 *   \brief Archivo de declaración de la clase Solver
 */
